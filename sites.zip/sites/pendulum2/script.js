document.addEventListener('DOMContentLoaded', () => {
  const themeToggle = document.getElementById('themeToggle');
  const pendulum = document.getElementById('pendulum');
  let isDark = false;
  let angle = 0;
  let direction = 1;
  const maxAngle = 30;
  const speed = 0.5;

  // Theme toggling
  themeToggle.addEventListener('click', () => {
    isDark = !isDark;
    document.documentElement.classList.toggle('dark');
  });

  // Pendulum animation
  function animatePendulum() {
    angle += direction * speed;
    
    if (angle >= maxAngle) {
      direction = -1;
    } else if (angle <= -maxAngle) {
      direction = 1;
    }
    
    pendulum.style.transform = `rotate(${angle}deg)`;
    requestAnimationFrame(animatePendulum);
  }

  animatePendulum();
});