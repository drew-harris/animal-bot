const colorBtn = document.getElementById('colorBtn');
const coolBox = document.getElementById('coolBox');
let isRotated = false;

const colors = [
    ['from-blue-500 to-green-500'],
    ['from-red-500 to-yellow-500'],
    ['from-purple-500 to-pink-500'],
    ['from-indigo-500 to-cyan-500']
];

let currentColorIndex = 0;

colorBtn.addEventListener('click', () => {
    currentColorIndex = (currentColorIndex + 1) % colors.length;
    coolBox.className = `h-32 w-full rounded-lg bg-gradient-to-r ${colors[currentColorIndex]} transform hover:scale-105 transition duration-300 cursor-pointer ${isRotated ? 'rotate-180' : ''}`;
});

coolBox.addEventListener('click', () => {
    isRotated = !isRotated;
    coolBox.style.transform = isRotated ? 'rotate(180deg)' : 'rotate(0deg)';
});