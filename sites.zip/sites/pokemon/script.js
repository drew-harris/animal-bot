const pokemonGrid = document.getElementById('pokemon-grid');
const loadingText = document.getElementById('loading');
const POKEMON_COUNT = 151;

async function fetchPokemon(id) {
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${id}`);
    const data = await response.json();
    return data;
}

async function displayPokemon() {
    try {
        for (let i = 1; i <= POKEMON_COUNT; i++) {
            const pokemon = await fetchPokemon(i);
            const pokemonCard = document.createElement('div');
            pokemonCard.className = 'bg-white rounded-lg shadow-md p-4 flex flex-col items-center transform hover:scale-105 transition-transform';
            
            pokemonCard.innerHTML = `
                <img src="${pokemon.sprites.front_default}" alt="${pokemon.name}" class="w-32 h-32">
                <h2 class="text-xl capitalize font-semibold">${pokemon.name}</h2>
                <div class="flex gap-2 mt-2">
                    ${pokemon.types.map(type => 
                        `<span class="px-3 py-1 rounded-full text-sm bg-gray-200">${type.type.name}</span>`
                    ).join('')}
                </div>
            `;
            
            pokemonGrid.appendChild(pokemonCard);
        }
        loadingText.style.display = 'none';
    } catch (error) {
        loadingText.textContent = 'Error loading Pokemon!';
        console.error('Error:', error);
    }
}

displayPokemon();