const activities = [
    "Learn to juggle",
    "Write a short story",
    "Cook a new recipe",
    "Start a garden",
    "Learn a new language",
    "Make origami",
    "Write a song",
    "Draw a self-portrait",
    "Build a pillow fort",
    "Create a time capsule",
    "Start a blog",
    "Learn magic tricks",
    "Make a bucket list",
    "Start a workout routine",
    "Learn to meditate"
];

function getRandomActivity() {
    const activityElement = document.getElementById('activity');
    const randomIndex = Math.floor(Math.random() * activities.length);
    activityElement.textContent = activities[randomIndex];
    
    // Add a little animation
    activityElement.style.opacity = 0;
    setTimeout(() => {
        activityElement.style.opacity = 1;
        activityElement.style.transition = 'opacity 0.5s ease-in';
    }, 100);
}

// Run once on page load
getRandomActivity();