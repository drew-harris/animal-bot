$(document).ready(function() {
    const btn = $('#runaway-btn');
    const maxX = window.innerWidth - btn.width();
    const maxY = window.innerHeight - btn.height();
    
    function getRandomPosition(max) {
        return Math.floor(Math.random() * max);
    }

    $(document).mousemove(function(e) {
        const btnPos = btn.offset();
        const mouseX = e.pageX;
        const mouseY = e.pageY;
        
        const distance = Math.sqrt(
            Math.pow(mouseX - btnPos.left, 2) + 
            Math.pow(mouseY - btnPos.top, 2)
        );
        
        if (distance < 100) {
            let newX = getRandomPosition(maxX);
            let newY = getRandomPosition(maxY);
            
            btn.css({
                left: newX + 'px',
                top: newY + 'px'
            });
        }
    });

    $(window).resize(function() {
        maxX = window.innerWidth - btn.width();
        maxY = window.innerHeight - btn.height();
    });
});