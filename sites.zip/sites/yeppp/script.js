function generateWebsite() {
    const title = document.getElementById('siteTitle').value;
    const theme = document.getElementById('colorTheme').value;
    const layout = document.getElementById('layout').value;
    const content = document.getElementById('content').value;
    
    let generatedHTML = `<!DOCTYPE html>
<html>
<head>
    <title>${title}</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="${getThemeClasses(theme)}">`;

    switch(layout) {
        case 'single':
            generatedHTML += generateSinglePage(title, content);
            break;
        case 'blog':
            generatedHTML += generateBlogLayout(title, content);
            break;
        case 'portfolio':
            generatedHTML += generatePortfolioLayout(title, content);
            break;
    }

    generatedHTML += `\n</body>\n</html>`;
    
    document.getElementById('output').textContent = generatedHTML;
    showPreview(generatedHTML);
}

function getThemeClasses(theme) {
    switch(theme) {
        case 'light':
            return 'bg-gray-100 text-gray-900';
        case 'dark':
            return 'bg-gray-900 text-white';
        case 'colorful':
            return 'bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-white';
        default:
            return '';
    }
}

function generateSinglePage(title, content) {
    return `
    <div class="max-w-4xl mx-auto p-8">
        <h1 class="text-4xl font-bold mb-8">${title}</h1>
        <div class="prose">
            ${content}
        </div>
    </div>`;
}

function generateBlogLayout(title, content) {
    const posts = content.split('\n\n');
    return `
    <div class="max-w-4xl mx-auto p-8">
        <h1 class="text-4xl font-bold mb-8">${title}</h1>
        ${posts.map(post => `
            <article class="mb-8 p-6 bg-white rounded-lg shadow">
                ${post}
            </article>
        `).join('')}
    </div>`;
}

function generatePortfolioLayout(title, content) {
    const items = content.split('\n\n');
    return `
    <div class="max-w-6xl mx-auto p-8">
        <h1 class="text-4xl font-bold mb-8">${title}</h1>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            ${items.map(item => `
                <div class="bg-white p-4 rounded-lg shadow">
                    ${item}
                </div>
            `).join('')}
        </div>
    </div>`;
}

function copyCode() {
    const output = document.getElementById('output');
    navigator.clipboard.writeText(output.textContent)
        .then(() => alert('Code copied to clipboard!'))
        .catch(err => console.error('Failed to copy code:', err));
}

function showPreview(html) {
    const preview = document.getElementById('preview');
    preview.innerHTML += html;
    preview.classList.remove('hidden');
}

function closePreview() {
    const preview = document.getElementById('preview');
    preview.innerHTML = `
        <button onclick="closePreview()" class="absolute top-4 right-4 bg-red-500 text-white px-4 py-2 rounded">
            Close Preview
        </button>
    `;
    preview.classList.add('hidden');
}