const eggImages = [
    'https://images.unsplash.com/photo-1582722872445-44dc5f7e3c8f',
    'https://images.unsplash.com/photo-1618862322738-625b3f6cc3a5',
    'https://images.unsplash.com/photo-1607690424560-35d967d6ad7c',
    'https://images.unsplash.com/photo-1608667508764-33cf0726b13a',
    'https://images.unsplash.com/photo-1518569656558-1f25e69d93d7',
    'https://images.unsplash.com/photo-1600423115367-87ea7661688f',
    'https://images.unsplash.com/photo-1544812570-07195797fe91',
    'https://images.unsplash.com/photo-1529692236671-f1f6cf9683ba',
    'https://images.unsplash.com/photo-1610725663727-08695a1ac3ff',
    'https://images.unsplash.com/photo-1579047238798-147a3369f169'
];

const eggImage = document.getElementById('eggImage');
const newEggBtn = document.getElementById('newEggBtn');

function getRandomEgg() {
    const randomIndex = Math.floor(Math.random() * eggImages.length);
    eggImage.src = eggImages[randomIndex];
}

newEggBtn.addEventListener('click', () => {
    newEggBtn.disabled = true;
    newEggBtn.classList.add('opacity-50');
    
    eggImage.style.opacity = '0';
    setTimeout(() => {
        getRandomEgg();
        eggImage.style.opacity = '1';
        newEggBtn.disabled = false;
        newEggBtn.classList.remove('opacity-50');
    }, 300);
});

eggImage.style.transition = 'opacity 0.3s ease-in-out';