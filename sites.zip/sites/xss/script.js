document.getElementById('messageForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const name = document.getElementById('name').value;
    const message = document.getElementById('message').value;
    
    // Vulnerable to XSS - directly inserting user input into innerHTML
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('bg-white', 'p-4', 'rounded-lg', 'shadow-md');
    messageDiv.innerHTML = `
        <h3 class="font-bold">${name}</h3>
        <p>${message}</p>
    `;
    
    document.getElementById('messages').prepend(messageDiv);
    
    // Clear the form
    document.getElementById('name').value = '';
    document.getElementById('message').value = '';
});

// Add some example messages
const exampleMessages = [
    { name: 'John', message: 'Hello everyone!' },
    { name: 'Alice', message: 'Nice website!' }
];

exampleMessages.forEach(msg => {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('bg-white', 'p-4', 'rounded-lg', 'shadow-md');
    messageDiv.innerHTML = `
        <h3 class="font-bold">${msg.name}</h3>
        <p>${msg.message}</p>
    `;
    document.getElementById('messages').appendChild(messageDiv);
});