async function sendRequest() {
    const apiKey = document.getElementById('apiKey').value;
    const prompt = document.getElementById('prompt').value;
    const responseDiv = document.getElementById('response');

    if (!apiKey || !prompt) {
        responseDiv.textContent = 'Please provide both API key and prompt';
        return;
    }

    responseDiv.textContent = 'Loading...';

    try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify({
                model: 'gpt-3.5-turbo',
                messages: [{
                    role: 'user',
                    content: prompt
                }],
                temperature: 0.7
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.error?.message || 'An error occurred');
        }

        responseDiv.textContent = data.choices[0].message.content;
    } catch (error) {
        responseDiv.textContent = `Error: ${error.message}`;
    }
}