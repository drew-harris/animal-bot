let currentPath = [];
const fileSystem = {
    'Documents': {
        'Work': {
            'report.txt': 'file',
            'presentation.pptx': 'file'
        },
        'Personal': {
            'photos': {
                'vacation.jpg': 'file',
                'family.jpg': 'file'
            },
            'notes.txt': 'file'
        }
    },
    'Downloads': {
        'software.exe': 'file',
        'movie.mp4': 'file'
    },
    'Desktop': {
        'shortcut.lnk': 'file',
        'Projects': {
            'web': {
                'index.html': 'file',
                'style.css': 'file'
            }
        }
    }
};

function renderFiles() {
    const fileList = document.getElementById('fileList');
    fileList.innerHTML = '';
    
    let currentLevel = fileSystem;
    for (let folder of currentPath) {
        currentLevel = currentLevel[folder];
    }
    
    for (let item in currentLevel) {
        const itemEl = document.createElement('div');
        itemEl.className = 'flex items-center p-2 hover:bg-gray-100 rounded cursor-pointer';
        
        const icon = document.createElement('span');
        icon.className = 'mr-2';
        icon.innerHTML = typeof currentLevel[item] === 'object' ? '📁' : '📄';
        
        const name = document.createElement('span');
        name.textContent = item;
        
        itemEl.appendChild(icon);
        itemEl.appendChild(name);
        
        if (typeof currentLevel[item] === 'object') {
            itemEl.onclick = () => navigateToFolder(item);
        }
        
        fileList.appendChild(itemEl);
    }
    
    updatePathDisplay();
}

function navigateToFolder(folderName) {
    currentPath.push(folderName);
    renderFiles();
}

function goBack() {
    if (currentPath.length > 0) {
        currentPath.pop();
        renderFiles();
    }
}

function updatePathDisplay() {
    const pathDisplay = document.getElementById('currentPath');
    pathDisplay.textContent = '/' + currentPath.join('/');
}

// Initial render
renderFiles();