// Weapon data
const weapons = [
    {
        name: "Liberator",
        type: "Assault Rifle",
        image: "https://placeholder.com/300x200",
        description: "Standard-issue rifle of the Helldivers"
    },
    {
        name: "Breaker",
        type: "Shotgun",
        image: "https://placeholder.com/300x200",
        description: "Close-quarters democracy spreader"
    },
    {
        name: "Railgun",
        type: "Heavy Weapon",
        image: "https://placeholder.com/300x200",
        description: "Armor-piercing freedom delivery system"
    },
    {
        name: "Expendable Anti-Tank",
        type: "Explosive",
        image: "https://placeholder.com/300x200",
        description: "Single-use democracy guarantee"
    }
];

// Populate weapons showcase
document.addEventListener('DOMContentLoaded', () => {
    const showcase = document.querySelector('#weapons-showcase div');
    
    weapons.forEach(weapon => {
        const card = document.createElement('div');
        card.className = 'bg-gray-800 p-4 rounded-lg hover:bg-gray-700 transition-colors cursor-pointer';
        card.innerHTML = `
            <img src="${weapon.image}" alt="${weapon.name}" class="w-full h-48 object-cover rounded-md mb-4">
            <h3 class="text-xl font-bold mb-2">${weapon.name}</h3>
            <p class="text-gray-400 text-sm mb-2">${weapon.type}</p>
            <p>${weapon.description}</p>
        `;
        showcase.appendChild(card);
    });

    // Smooth scroll for Learn More button
    document.querySelector('#learn-more').addEventListener('click', () => {
        window.scrollTo({
            top: window.innerHeight,
            behavior: 'smooth'
        });
    });

    // CTA button animation
    const ctaButton = document.querySelector('#cta-button');
    ctaButton.addEventListener('click', () => {
        window.open('https://store.steampowered.com/app/553850/HELLDIVERS_2/', '_blank');
    });

    // Parallax effect for header
    window.addEventListener('scroll', () => {
        const video = document.querySelector('video');
        const scrolled = window.pageYOffset;
        video.style.transform = `translateY(${scrolled * 0.5}px)`;
    });
});