// Dark mode toggle functionality
const darkModeToggle = document.getElementById('darkModeToggle');
const html = document.documentElement;

darkModeToggle.addEventListener('click', () => {
    html.classList.toggle('dark');
});

// Pendulum animation
const pendulumString = document.getElementById('pendulum-string');
let angle = 0;
const maxAngle = 30;
const speed = 0.02;
let direction = 1;

function animatePendulum() {
    angle += speed * direction;
    
    if (Math.abs(angle) >= maxAngle) {
        direction *= -1;
    }
    
    pendulumString.style.transform = `rotate(${angle}deg)`;
    requestAnimationFrame(animatePendulum);
}

animatePendulum();