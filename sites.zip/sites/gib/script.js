function showToken() {
    const token = document.getElementById('token').value;
    if (!token) {
        alert('Please enter a token first!');
        return;
    }
    const tokenDisplay = document.getElementById('tokenDisplay');
    tokenDisplay.textContent = token;
    tokenDisplay.classList.remove('hidden');
}

function hideToken() {
    const tokenDisplay = document.getElementById('tokenDisplay');
    tokenDisplay.textContent = '';
    tokenDisplay.classList.add('hidden');
    document.getElementById('token').value = '';
}